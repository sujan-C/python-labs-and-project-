input="“P@#yn26at^&i5ve"
alphabets=0
digits=0
special_char=0
for i in range(len(input)):
    if(input[i].isalpha()):
        alphabets += 1
    elif(input[i].isdigit()):
        digits += 1
    else:
        special_char += 1
print(f"alphabets = {alphabets} Digits = {digits} special_char = {special_char}")
