string="String and String Function"
string.split()
string_without_duplicates= " "
for char in string:
    if char not in string_without_duplicates:
        string_without_duplicates += char
print("String after removing duplicates elements is: ",string_without_duplicates)
