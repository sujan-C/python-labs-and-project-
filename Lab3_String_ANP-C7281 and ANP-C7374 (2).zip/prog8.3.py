def reverse_words(string):
    words = string.split()
    reversed_words = words[::-1]
    reversed_string = ' '.join(reversed_words)  
    return reversed_string
string = "Deeptech Python Training"
reversed_string = reverse_words(string)
print(reversed_string)
