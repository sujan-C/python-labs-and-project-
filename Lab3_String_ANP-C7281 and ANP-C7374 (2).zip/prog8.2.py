def remove_newline(string):
    return string.replace('\n', '')
string = "\nBest \nDeeptech \nPython \nTraining\n"
string_without_newline = remove_newline(string)
print(string_without_newline)
