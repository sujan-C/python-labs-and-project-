#creating Three dictionary
d1 = {1: 10, 2: 20}
d2 = {3: 30, 4: 40}
d3 = {5: 50, 6: 60}

dic4 = {}
for d in (d1, d2, d3):
    dic4.update(d)
print(dic4)#Print the Output
