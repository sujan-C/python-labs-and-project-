def calc_mean(test_dict):
    total= sum(test_dict.values())
    mean = total/ len(test_dict)
    
    return mean

test_dict = {"A" : 6, "B" : 9, "C" : 5, "D" : 7, "E" : 4}#Given Dictionaries for calculating mean 
mean = calc_mean(test_dict)
print("Mean:", mean)
