dict_num = {1: 10, 2: 20, 3: 30, 4: 40, 5: 50, 6: 60}
#\t\t -add two tab spaces between the "Keys:" and "Values:"
print("Key\t\tValue")
for key in dict_num:
    print(key, "\t\t", dict_num[key])
