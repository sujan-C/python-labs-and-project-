def check_number():
    while True:
        try:
            number = float(input("Enter a number: "))
            break
        except ValueError:
            print("Invalid input. Please enter a valid number.")

    if number > 0:
        print("The number is positive.")
    elif number < 0:
        print("The number is negative.")
    else:
        print("The number is zero.")
check_number()
