fibonacci_series = []
a, b = 0, 1
for i in range(50):
    if a > 50:
        break
    fibonacci_series.append(a)
    a, b = b, a + b
print("Fibonacci series between 0 to 50:")
for num in fibonacci_series:
    print(num, end=" ")
